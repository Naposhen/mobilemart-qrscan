/** Automatically generated file. DO NOT MODIFY */
package com.kde.qrscan;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
package com.kde.qrscan;

import com.kde.qrscan.webRequest.ghttpRequest;

import android.os.Bundle;
import android.preference.PreferenceManager;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class Main extends Activity {
	private SharedPreferences thispref;
	private String serveraddr;
	private Context thiscontext = this;
	private AlertDialog alert;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		thispref = PreferenceManager
				.getDefaultSharedPreferences(this);
		serveraddr = thispref.getString("serveraddr", "127.0.0.1");
		
		alert = new AlertDialog.Builder(this).create();
		alert.setTitle("Messages");
		alert.setCancelable(false);
		alert.setCanceledOnTouchOutside(false);

		Button startscan = (Button) findViewById(R.id.scan);
		startscan.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(
						"com.google.zxing.client.android.SCAN");
				intent.putExtra("SCAN_MODE", "SCAN_MODE");
				startActivityForResult(intent, 0);
			}
		});
		Button adminlogin = (Button) findViewById(R.id.admin);
		adminlogin.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent calllogin = new Intent("com.kde.qrscan.adminlogin");
				startActivity(calllogin);
			}
		});
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent intent) {
		if (requestCode == 0) {
			if (resultCode == RESULT_OK) {
				Static st = new Static();
				final String barcode = intent.getStringExtra("SCAN_RESULT");
				System.out.println(barcode);
				//String format = intent.getStringExtra("SCAN_RESULT_FORMAT");
				// Handle successful scan
				
				//Toast.makeText(getApplicationContext(), contents, Toast.LENGTH_SHORT).show();
				ghttpRequest getdata = new ghttpRequest(thiscontext,"Check Existing...",30000,new webRequest.wCallback(){
					@Override
					public void run(String result) {
						if(result.length()>0) {
							result = result.trim();
							System.out.println(result);
							if(result.equals("NotFound")) {
								alert.setMessage("Data Barcode ini Tidak Ketemu...");
								alert.setButton(DialogInterface.BUTTON_NEGATIVE,"OK",new DialogInterface.OnClickListener(){
									@Override
									public void onClick(DialogInterface dialog,int which) {
										Intent intent = new Intent(
												"com.google.zxing.client.android.SCAN");
										intent.putExtra("SCAN_MODE", "SCAN_MODE");
										startActivityForResult(intent, 0);										
									}
									
								});
								alert.show();
							} else {
								
								Intent callview = new Intent("com.kde.qrscan.viewdata");
								callview.putExtra("data", result);
								startActivityForResult(callview,50);
								
							}
						} else {
							alert.setMessage("Error Request Data...");
							alert.show();
							
						}
					}
				});
				getdata.execute("http://"+serveraddr+"/android/chkexist.php?data="+st.urlencode(barcode));
			} else if (resultCode == RESULT_CANCELED) {
				// Handle cancel
				Log.i("App", "Scan unsuccessful");
			}
		} else if(requestCode == 50) {
			Intent intent0 = new Intent(
					"com.google.zxing.client.android.SCAN");
			intent0.putExtra("SCAN_MODE", "SCAN_MODE");
			startActivityForResult(intent0, 0);													
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		if(item.getItemId()==R.id.action_settings) {
			Intent calpref = new Intent("com.kde.qrscan.pref");
			startActivityForResult(calpref,200);
			return true;
		}
		
		return super.onOptionsItemSelected(item);
	}

}

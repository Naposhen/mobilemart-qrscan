package com.kde.qrscan;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import android.util.Base64;

public class Static {
    public String base64e(String d) {
	    byte[] data = null;
	    try {
	        data = d.getBytes("UTF-8");
	    } catch (UnsupportedEncodingException e1) {
	    	e1.printStackTrace();
	    }
	    return Base64.encodeToString(data, Base64.DEFAULT);
    }

    public String base64d(String d) {
    	String ret = null;
	    try {
		    byte[] data1 = Base64.decode(d, Base64.DEFAULT);
	        ret = new String(data1, "UTF-8");
	    } catch (UnsupportedEncodingException e) {
	        e.printStackTrace();
	    }
	    return ret;
    }

    public String urlencode(String d) {
    	String ret = null;
	    try {
	        ret = URLEncoder.encode(d, "utf-8");
	    } catch (UnsupportedEncodingException e) {
	        e.printStackTrace();
	    }
	    return ret;
    }


}

package com.kde.qrscan;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import com.kde.qrscan.webRequest.ghttpRequest;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class adminlogin extends Activity {
	private SharedPreferences thispref;
	private String serveraddr;
	private EditText user;
	private EditText pass;
	private AlertDialog alert;
	private Context thiscontext = this;
	private String getuser;
	private String getpass;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.adminlogin);
		thispref = PreferenceManager
				.getDefaultSharedPreferences(this);
		serveraddr = thispref.getString("serveraddr", "127.0.0.1");
		
		user = (EditText) findViewById(R.id.username);
		pass = (EditText) findViewById(R.id.passwd);
		user.setSingleLine(true);
		user.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_SUBJECT);
		//pass.setSingleLine(true);
		//pass.setInputType(android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
		
		alert = new AlertDialog.Builder(this).create();
		alert.setTitle("Error Login");
		alert.setButton(DialogInterface.BUTTON_NEGATIVE,"OK",(DialogInterface.OnClickListener) null);
		alert.setCancelable(false);
		alert.setCanceledOnTouchOutside(false);

		
		Button loginbtn = (Button) findViewById(R.id.gologin);
		loginbtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Static st = new Static();
				getuser = user.getText().toString().trim();
				getpass = md5(pass.getText().toString().trim());
				System.out.println(st.urlencode(getuser));
				
				if(getuser.length()==0) {
					alert.setMessage("UserName Kosong...");
					alert.show();
					user.requestFocus();
					return;					
				}
				
				if(getpass.length()==0) {
					alert.setMessage("Password Kosong...");
					alert.show();
					user.requestFocus();
					return;					
				}
				
				ghttpRequest getdata = new ghttpRequest(thiscontext,"Verifying...",30000,new webRequest.wCallback(){
					@Override
					public void run(String result) {
						if(result.length()>0) {
							result = result.trim();
							System.out.println(result);
							if(result.equals(getpass)) {
								
								Intent calllogin = new Intent("com.kde.qrscan.adminmenu");
								startActivityForResult(calllogin,300);
							} else {
								alert.setMessage("Password Salah...");
								alert.show();
								
							}
						} else {
							alert.setMessage("Error Request Data...");
							alert.show();

						}
					}
				});
				getdata.execute("http://"+serveraddr+"/android/verify.php?user="+st.urlencode(getuser));
				
			}
		});

		
		Button logincancel = (Button) findViewById(R.id.gocancel);
		logincancel.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				finish();
			}
		});
		
	}
	
	public String md5(String s) {
	    try {
	        // Create MD5 Hash
	        MessageDigest digest = java.security.MessageDigest.getInstance("MD5");
	        digest.update(s.getBytes());
	        byte messageDigest[] = digest.digest();

	        // Create Hex String
	        StringBuffer hexString = new StringBuffer();
	        for (int i=0; i<messageDigest.length; i++)
	            hexString.append(Integer.toHexString(0xFF & messageDigest[i]));
	        return hexString.toString();

	    } catch (NoSuchAlgorithmException e) {
	        e.printStackTrace();
	    }
	    return "";
	}	

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent intent) {
		if (requestCode == 300) {
			finish();
		}
	}

}

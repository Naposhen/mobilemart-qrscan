package com.kde.qrscan;

import com.kde.qrscan.webRequest.ghttpRequest;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;

public class adminmenu extends Activity {
	private SharedPreferences thispref;
	private String serveraddr;
	private Context thiscontext = this;
	private AlertDialog alert;
	private LinearLayout btn1;
	private LinearLayout btn2;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.adminmenu);

		thispref = PreferenceManager
				.getDefaultSharedPreferences(this);
		serveraddr = thispref.getString("serveraddr", "127.0.0.1");
		
		alert = new AlertDialog.Builder(this).create();
		alert.setTitle("Messages");
		alert.setCancelable(false);
		alert.setCanceledOnTouchOutside(false);

		btn1 = (LinearLayout) findViewById(R.id.gosearch);
		btn1.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				Intent calllist = new Intent("com.kde.qrscan.productlist");
				startActivity(calllist);			
			}
			
		});
		btn2 = (LinearLayout) findViewById(R.id.gonewitem);
		btn2.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				Intent intent = new Intent(
						"com.google.zxing.client.android.SCAN");
				intent.putExtra("SCAN_MODE", "SCAN_MODE");
				startActivityForResult(intent, 0);
			}
			
		});
	}
	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent intent) {
		if (requestCode == 0) {
			if (resultCode == RESULT_OK) {
				Static st = new Static();
				final String barcode = intent.getStringExtra("SCAN_RESULT");
				System.out.println(barcode);
				//String format = intent.getStringExtra("SCAN_RESULT_FORMAT");
				// Handle successful scan
				
				//Toast.makeText(getApplicationContext(), contents, Toast.LENGTH_SHORT).show();
				ghttpRequest getdata = new ghttpRequest(thiscontext,"Check Existing...",30000,new webRequest.wCallback(){
					@Override
					public void run(String result) {
						if(result.length()>0) {
							result = result.trim();
							System.out.println(result);
							if(result.equals("NotFound")) {
								Intent callnew = new Intent("com.kde.qrscan.new");
								callnew.putExtra("data", barcode);
								startActivityForResult(callnew,60);
							} else {
								alert.setMessage("Data Barcode ini Telah Ada...");
								alert.setButton(DialogInterface.BUTTON_NEGATIVE,"OK",new DialogInterface.OnClickListener(){
									@Override
									public void onClick(DialogInterface dialog,int which) {
										Intent intent = new Intent(
												"com.google.zxing.client.android.SCAN");
										intent.putExtra("SCAN_MODE", "SCAN_MODE");
										startActivityForResult(intent, 0);										
									}
									
								});
								alert.show();								
							}
						} else {
							alert.setMessage("Error Request Data...");
							alert.show();
							
						}
					}
				});
				getdata.execute("http://"+serveraddr+"/android/chkexist.php?data="+st.urlencode(barcode));
			} else if (resultCode == RESULT_CANCELED) {
				// Handle cancel
				Log.i("App", "Scan unsuccessful");
			}
		}
	}	
}

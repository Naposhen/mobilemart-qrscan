package com.kde.qrscan;

import java.util.ArrayList;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class datalistAdapter extends BaseAdapter {
	private ArrayList<struct> list;
	private LayoutInflater mInflater;

	public datalistAdapter (Context context,ArrayList<struct> results) {
		  list = results;
		  mInflater = LayoutInflater.from(context);
	}
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return list.size();
	}

	@Override
	public Object getItem(int arg0) {
		// TODO Auto-generated method stub
		return list.get(arg0);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}
	 public void refresh() {
		 this.notifyDataSetChanged();
	 }

	@Override
	@SuppressLint("DefaultLocale")
	public View getView(int position, View v, ViewGroup parent) {
		ViewHolder holder;
		if(v==null) {
			holder = new ViewHolder();
			v = mInflater.inflate(android.R.layout.simple_list_item_1, null);
			holder.txt = (TextView) v.findViewById(android.R.id.text1);
			holder.txt.setTextSize(18);
			v.setTag(holder);
		} else {holder = (ViewHolder) v.getTag(); }
		
		holder.txt.setText(list.get(position).getName());
		//System.out.println("spin"+position);
        return v;
	}

	class ViewHolder {
		TextView txt;
	}
}

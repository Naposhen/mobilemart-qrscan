package com.kde.qrscan;

import com.kde.qrscan.webRequest.ghttpRequest;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class detail extends Activity {
	private SharedPreferences thispref;
	private String serveraddr;
	private EditText id;
	private EditText name;
	private EditText cate;
	private EditText unit;
	private EditText loc;
	private EditText exp;
	private EditText price;
	private Context thiscontext = this;
	private AlertDialog alert;
	private String submitdata;
	private int pos,oripos;
	private Static st = new Static();
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.detail);
		thispref = PreferenceManager
				.getDefaultSharedPreferences(this);
		serveraddr = thispref.getString("serveraddr", "127.0.0.1");

		Bundle bundle = getIntent().getExtras();
        String detail = bundle.getString("datadetail");
        pos = bundle.getInt("pos");
        
        String[] adetail = detail.split(";;;");
 
		alert = new AlertDialog.Builder(this).create();
		alert.setTitle("Messages");
		alert.setButton(DialogInterface.BUTTON_NEGATIVE,"OK",(DialogInterface.OnClickListener) null);
		alert.setCancelable(false);
		alert.setCanceledOnTouchOutside(false);

        id = (EditText) findViewById(R.id.d_id);
        name = (EditText) findViewById(R.id.d_name);
        cate = (EditText) findViewById(R.id.d_cate);
        unit = (EditText) findViewById(R.id.d_unit);
        loc = (EditText) findViewById(R.id.d_location);
        exp = (EditText) findViewById(R.id.d_exp);
        price = (EditText) findViewById(R.id.d_price);
                
        id.setText(adetail[0]);
        name.setText(adetail[1]);
        cate.setText(adetail[2]);
        unit.setText(adetail[3]);
        loc.setText(adetail[4]);
        exp.setText(adetail[5]);
        price.setText(adetail[6]);
        oripos = Integer.valueOf(adetail[7]);
        
        System.out.println(pos);
        System.out.println(oripos);
        
        name.requestFocus();
        
        Button dsave = (Button) findViewById(R.id.d_save);
        Button ddel = (Button) findViewById(R.id.d_del);
        Button dcancel = (Button) findViewById(R.id.d_cancel);
        
        dsave.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v) {
				String tmp1=id.getText().toString().trim();
				if(tmp1.length()==0) {
					alert.setMessage("Invalid ID / Barcode");
					alert.show();
					id.requestFocus();
					return;
				}
				String tmp2=name.getText().toString().trim();
				if(tmp2.length()==0) {
					alert.setMessage("Invalid Nama Item");
					alert.show();
					name.requestFocus();
					return;
				}
				String tmp3=cate.getText().toString().trim();
				if(tmp3.length()==0) {
					alert.setMessage("Invalid Kategori Item");
					alert.show();
					cate.requestFocus();
					return;
				}
				String tmp4=unit.getText().toString().trim();
				if(tmp4.length()==0) {
					alert.setMessage("Invalid Unit");
					alert.show();
					unit.requestFocus();
					return;
				}
				String tmp5=loc.getText().toString().trim();
				if(tmp5.length()==0) {
					alert.setMessage("Invalid Location Item");
					alert.show();
					loc.requestFocus();
					return;
				}
				String tmp6=exp.getText().toString().trim();
				if(tmp6.length()==0) {
					alert.setMessage("Invalid Expriy Item");
					alert.show();
					exp.requestFocus();
					return;
				}
				String tmp7=price.getText().toString().trim();
				if(tmp7.length()==0 || Integer.valueOf(tmp7)<=0) {
					alert.setMessage("Invalid Price");
					alert.show();
					price.requestFocus();
					return;
				}
				submitdata = tmp1+";;;"+tmp2+";;;"+tmp3+";;;"+tmp4+";;;"+tmp5+";;;"+tmp6+";;;"+tmp7;
				System.out.println(submitdata);
				ghttpRequest getdata = new ghttpRequest(thiscontext,"Updating Stock Data...",30000,new webRequest.wCallback(){
					@Override
					public void run(String result) {
						if(result.contains("Success")) {
							Toast.makeText(getApplicationContext(), "Simpan Data Edit Sukses...!", Toast.LENGTH_SHORT).show();
							Intent returndata = new Intent();
							returndata.putExtra("returndata", submitdata);
							returndata.putExtra("pos", pos);
							returndata.putExtra("oripos", oripos);
							setResult(1,returndata);
							finish();
						} else {
							Toast.makeText(getApplicationContext(), result, Toast.LENGTH_SHORT).show();
						}
					}
				});
				getdata.execute("http://"+serveraddr+"/android/editsave.php?data="+st.urlencode(submitdata));
				
			}
        	
        });
        ddel.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v) {
				String tmp1=id.getText().toString().trim();
				ghttpRequest getdata = new ghttpRequest(thiscontext,"Deleting Stock Data...",30000,new webRequest.wCallback(){
					@Override
					public void run(String result) {
						if(result.contains("Success")) {
							Toast.makeText(getApplicationContext(), "Hapus Data Sukses...!", Toast.LENGTH_SHORT).show();
							Intent returndata = new Intent();
							returndata.putExtra("pos", pos);
							returndata.putExtra("oripos", oripos);
							setResult(2,returndata);
							finish();
						} else {
							Toast.makeText(getApplicationContext(), result, Toast.LENGTH_SHORT).show();
						}
					}
				});
				getdata.execute("http://"+serveraddr+"/android/deletestock.php?data="+st.urlencode(tmp1));
				
			}
        	
        });
        dcancel.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v) {
				finish();
			}
        	
        });
	}

}

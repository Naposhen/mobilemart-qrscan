package com.kde.qrscan;

import java.util.ArrayList;

import com.kde.qrscan.webRequest.ghttpRequest;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.EditText;
import android.widget.ListView;

public class productlist extends Activity {
	private SharedPreferences thispref;
	private String serveraddr;
	private Context thiscontext= this;
	private ListView pl;
	private EditText keyword;
	private ArrayList<struct> data,tmpdata;
	private datalistAdapter adapter;
	private AlertDialog alert;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.productlist);
		thispref = PreferenceManager
				.getDefaultSharedPreferences(this);
		serveraddr = thispref.getString("serveraddr", "127.0.0.1");
		
		alert = new AlertDialog.Builder(this).create();
		alert.setTitle("Messages");
		alert.setButton(DialogInterface.BUTTON_NEGATIVE,"OK",(DialogInterface.OnClickListener) null);
		alert.setCancelable(false);
		alert.setCanceledOnTouchOutside(false);
		
		keyword = (EditText) findViewById(R.id.editText_search);
		keyword.setSingleLine(true);
		keyword.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_SUBJECT);
		keyword.addTextChangedListener(new TextWatcher(){

			@Override
			public void afterTextChanged(Editable s) {
				
			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,int after) {
				
			}

			@SuppressLint("DefaultLocale")
			@Override
			public void onTextChanged(CharSequence s, int start, int before,int count) {
				tmpdata.clear();
				String find = keyword.getText().toString().trim().toLowerCase();
				if(find.length()>0) {
					for(int i=0;i<data.size();i++) {
						String productname = data.get(i).getName().toLowerCase();
						if(productname.contains(find)) {
							tmpdata.add(data.get(i));
						}
					}
				} else {
					for(int i=0;i<data.size();i++) {
						tmpdata.add(data.get(i));
					}					
				}
				adapter.refresh();
			}
			
		});
		
		pl = (ListView) findViewById(R.id.listView1_product);
		data = new ArrayList<struct>();
		tmpdata = new ArrayList<struct>();
		adapter = new datalistAdapter(this,tmpdata);
		
		pl.setOnItemClickListener(new OnItemClickListener(){

			@Override
			public void onItemClick(AdapterView<?> adapter, View v, int pos,long id) {
				String datadetail = tmpdata.get(pos).getId()+";;;"+
						tmpdata.get(pos).getName()+";;;"+
						tmpdata.get(pos).getCate()+";;;"+
						tmpdata.get(pos).getUnit()+";;;"+
						tmpdata.get(pos).getLocation()+";;;"+
						tmpdata.get(pos).getExp()+";;;"+
						String.valueOf(tmpdata.get(pos).getPrice())+";;;"+
						String.valueOf(tmpdata.get(pos).oriPos());
				Intent calldetail = new Intent("com.kde.qrscan.detail");
				calldetail.putExtra("datadetail", datadetail);
				calldetail.putExtra("pos", pos);
				startActivityForResult(calldetail,100);
				
			}
			
		});
		pl.setAdapter(adapter);
		data.clear();
		tmpdata.clear();
		getdata();
		
	}
	
	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent intent) {
		if (requestCode == 100) {
			if (resultCode == 1) {
				String returndata = intent.getStringExtra("returndata");
				int datapos = intent.getIntExtra("pos", 0);
				int dataoripos = intent.getIntExtra("oripos", 0);
				System.out.println(returndata);
				System.out.println(datapos);
				System.out.println(dataoripos);
				String[] tmp = returndata.split(";;;");
				data.get(dataoripos).setName(tmp[1]);
				tmpdata.get(datapos).setName(tmp[1]);
				data.get(dataoripos).setCate(tmp[2]);
				tmpdata.get(datapos).setCate(tmp[2]);
				data.get(dataoripos).setUnit(tmp[3]);
				tmpdata.get(datapos).setUnit(tmp[3]);
				data.get(dataoripos).setLocation(tmp[4]);
				tmpdata.get(datapos).setLocation(tmp[4]);
				data.get(dataoripos).setExp(tmp[5]);
				tmpdata.get(datapos).setExp(tmp[5]);
				data.get(dataoripos).setPrice(Integer.valueOf(tmp[6]));
				tmpdata.get(datapos).setPrice(Integer.valueOf(tmp[6]));
				
				adapter.refresh();
			} else if(resultCode == 2) {
				int datapos = intent.getIntExtra("pos", 0);
				int dataoripos = intent.getIntExtra("oripos", 0);
				data.remove(dataoripos);
				tmpdata.remove(datapos);
				adapter.refresh();				
			}
		}
	}
	
	// timeout set bit longer (25000) because its may a first time data load from server....
	private void getdata() {
        ghttpRequest getdata = new ghttpRequest(thiscontext,"Loading Product List...",30000,new webRequest.wCallback(){
			@Override
			public void run(String result) {
				String[] splitdata;
				String[] separated;
				String[] item;
				System.out.println("finish getdata");
				if(result.length()>0) {
					splitdata = result.split(";~;~;");
					if(splitdata[0].equals("httpok")) {									        		
						separated = splitdata[1].split("___");
						for (int i=0; i<separated.length; i++){
							struct tmp = new struct();
							item = separated[i].split(";;;");
							tmp.setId(item[0]);
							tmp.setName(item[1]);
							tmp.setCate(item[2]);
							tmp.setUnit(item[3]);
							tmp.setLocation(item[4]);
							tmp.setExp(item[5]);
							tmp.setPrice(Integer.valueOf(item[6]));
							tmp.setOripos(i);
							
							data.add(tmp);
							tmpdata.add(tmp);
							System.out.println(item[1]);
						}
						separated=null;
					} else {
						alert.setMessage(result);
						alert.show();						
					}
					splitdata=null;
					result=null;
				} else {
					alert.setMessage("Error Request Data...");
					alert.show();
					
				}
				adapter.refresh();
			}
		});
		getdata.execute("http://"+serveraddr+"/android/getdata.php");
	}

}

package com.kde.qrscan;

public class struct {
	String id;
	String name_item;
	String cate_item;
	String unit;
	String location_item;
	String exp_item;
	int price_item;
	int oripos;
	
	public String getId() {
		return this.id;
	}
	public String getName() {
		return this.name_item;
	}
	public String getCate() {
		return this.cate_item;
	}
	public String getUnit() {
		return this.unit;
	}
	public String getLocation() {
		return this.location_item;
	}
	public String getExp() {
		return this.exp_item;
	}
	public int getPrice() {
		return this.price_item;
	}
	public int oriPos() {
		return this.oripos;
	}
	
	
	public void setId(String id) {
		this.id = id;
	}
	public void setName(String name) {
		this.name_item = name;
	}
	public void setCate(String cate) {
		this.cate_item = cate;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	public void setLocation(String loc) {
		this.location_item = loc;
	}
	public void setExp(String exp) {
		this.exp_item = exp;
	}
	public void setPrice(int price) {
		this.price_item = price;
	}
	public void setOripos(int pos) {
		this.oripos = pos;
	}

}

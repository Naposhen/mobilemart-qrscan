package com.kde.qrscan;

import android.app.Activity;
import android.os.Bundle;
import android.widget.EditText;

public class viewdata extends Activity {
	private EditText id;
	private EditText name;
	private EditText cate;
	private EditText unit;
	private EditText loc;
	private EditText exp;
	private EditText price;

	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.viewdata);
		Bundle bundle = getIntent().getExtras();
        String detail = bundle.getString("data");
        String[] adetail = detail.split(";;;");
        
        id = (EditText) findViewById(R.id.v_id);
        name = (EditText) findViewById(R.id.v_name);
        cate = (EditText) findViewById(R.id.v_cate);
        unit = (EditText) findViewById(R.id.v_unit);
        loc = (EditText) findViewById(R.id.v_location);
        exp = (EditText) findViewById(R.id.v_exp);
        price = (EditText) findViewById(R.id.v_price);
        
        price.setFocusable(false);
        price.setFocusableInTouchMode(false);
                
        id.setText(adetail[0]);
        name.setText(adetail[1]);
        cate.setText(adetail[2]);
        unit.setText(adetail[3]);
        loc.setText(adetail[4]);
        exp.setText(adetail[5]);
        price.setText(adetail[6]);
	}

}

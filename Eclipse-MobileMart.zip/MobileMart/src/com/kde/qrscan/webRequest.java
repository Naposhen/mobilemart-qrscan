package com.kde.qrscan;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.CoreConnectionPNames;
import org.apache.http.params.HttpParams;
import org.apache.http.protocol.HTTP;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.preference.PreferenceManager;

public class webRequest {
	private static SharedPreferences thispref;
	
	public static String wget (String url,int timeout) throws Exception {
		final HttpClient Client = new DefaultHttpClient();
        String response = null;
        try {
            HttpGet httpget = new HttpGet(url);
            httpget.addHeader("Content-Type","text/html; charset=UTF-8");
            httpget.addHeader("Cache-Control","no-cache");
            setTimeouts(httpget.getParams(),timeout);
            ResponseHandler<String> responseHandler = new BasicResponseHandler();
            response = Client.execute(httpget, responseHandler);
            //System.out.println("response: "+response);
        } catch (ClientProtocolException e) {
        	System.out.println("ClientProtocolException: "+e.toString());
        	response = "";
        } catch (IOException e) {
        	System.out.println("IOException: "+e.toString());
        	response = "";
        } catch (Exception e) {
        	System.out.println("Exception: "+e.toString());
            System.out.println("url: "+url);
       	response = "";
        }
        if (response.contains("connect fail")) {response="cf";}
        else if (response.contains("timed out")) {response="to";}
        else if (response.contains(">Warning<")) {response="w";}
		return response;
	}
	public static String wpost (String url, ArrayList<NameValuePair> posparams,int timeout) throws Exception {
		final HttpClient Client = new DefaultHttpClient();
        String response;
        try {
            HttpPost post = new HttpPost(url); 
            setTimeouts(post.getParams(),timeout);
            post.addHeader("Content-Type","text/html; charset=UTF-8");
            post.addHeader("Cache-Control","no-cache");
           response = null;
            UrlEncodedFormEntity ent = new UrlEncodedFormEntity(posparams,HTTP.UTF_8);
            post.setEntity(ent);
               
            response = Client.execute(post, new BasicResponseHandler());
        } catch (ClientProtocolException e) {
        	System.out.println(e.toString());
        	response = "";
        } catch (IOException e) {
        	System.out.println(e.toString());
			response = "";
        } catch (Exception e) {
        	System.out.println(e.toString());
        	response = "";
        }
		
        if (response.contains("connect fail")) {response="";}
        else if (response.contains("timed out")) {response="";}
        else if (response.contains(">Warning<")) {response="";}
		return response;
	}
	
	private static void setTimeouts(HttpParams params,int timeout) {
	    params.setIntParameter(CoreConnectionPNames.CONNECTION_TIMEOUT,timeout);
	    params.setIntParameter(CoreConnectionPNames.SO_TIMEOUT, timeout);
	    //params.setIntParameter(ConnManagerPNames.TIMEOUT, timeout);
	}
	
	public static interface wCallback {
		void run(String result);
	}


	/*
	public static class getBitmapFromURL extends AsyncTask<String,Void,Bitmap> {

		@Override
		protected Bitmap doInBackground(String... params) {
			BitmapFactory.Options bfOptions=new BitmapFactory.Options();
			bfOptions.inDither=false;                     //Disable Dithering mode
			bfOptions.inPurgeable=true;                   //Tell to gc that whether it needs free memory, the Bitmap can be cleared
			bfOptions.inInputShareable=true;              //Which kind of reference will be used to recover the Bitmap data after being clear, when it will be used in the future
			bfOptions.inTempStorage=new byte[16 * 1024]; 
			bfOptions.inPreferredConfig = Config.RGB_565;
			try {
				URL url = new URL(params[0]);
				HttpURLConnection connection = (HttpURLConnection) url.openConnection();
				connection.setDoInput(true);
				connection.connect();
				InputStream input = connection.getInputStream();
				return BitmapFactory.decodeStream(input, null, bfOptions);
			} catch (FileNotFoundException e) {
				return null;
			} catch (IOException e) {
	        	System.out.println(e.getMessage());
				return null;
			}
		}

		@Override
		protected void onPostExecute(Bitmap result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
		}
		
	}

	*/
	
	public static class ghttpRequest extends AsyncTask<String, Void, String> {
				
        private ProgressDialog pDialog;
 		private String result;
 		private Context thiscontext;
 		private String pMsg;
 		private wCallback cbfunc;
 		private int timeout;
 		private String enablelog;
 	
 		public ghttpRequest(Context context,String msg,int to,wCallback cb){
 			thiscontext = context;
  			pDialog = new ProgressDialog(thiscontext);
  			pDialog.setTitle("Please Wait...");
 			pMsg = msg;
 			cbfunc = cb;
 			timeout=to;
            thispref = PreferenceManager.getDefaultSharedPreferences(thiscontext);
            enablelog = thispref.getString("enablelog", "1");
  		}
 		
        @Override
		protected void onPreExecute() {
        	if(pMsg!=null) {
	        	pDialog.setCancelable(false);
				pDialog.setCanceledOnTouchOutside(false);
	            pDialog.setMessage(pMsg);
	            pDialog.show();
        	}
        }
        
        @Override
		protected String doInBackground(String... arg0) {
			// TODO Auto-generated method stub
           	try {
           		result = wget(arg0[0],timeout);
     		} catch (Exception e) {
            	System.out.println(e.toString());
     			result = "";
          		if(enablelog.equals("1")) {
           		}
    		}

			return result;
		}
		@Override
		protected void onPostExecute(String result) {
			dismissDialog();
            cbfunc.run(result);
		}
		
		public void dismissDialog() {
        	if(pMsg!=null) {
        		pDialog.dismiss();
        	}
		}
	}

	
}
